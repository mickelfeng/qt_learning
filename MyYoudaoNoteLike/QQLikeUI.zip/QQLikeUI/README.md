#QQLikeUI
qt版本：5.3.2 编译器：mingw32

只实现了登录界面
几乎是用纯qss实现全部界面小特效
运行效果如下，左边为原版，右边为“山寨”：
![](http://git.oschina.net/kyyblabla/QQLikeUI/raw/master/%E8%BF%90%E8%A1%8C%E5%AF%B9%E6%AF%94.jpg)